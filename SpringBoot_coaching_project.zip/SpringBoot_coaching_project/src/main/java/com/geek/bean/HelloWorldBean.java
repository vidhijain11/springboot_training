package com.geek.bean;

public class HelloWorldBean {
	
	private String msg;
	
	public HelloWorldBean() {
		System.out.println("Constructor");
	}

	public void setMsg(String msg) {
		this.msg = msg;
		System.out.println("Setter");
	}
	
	public String sayHello(String name) {
		return "Hi " + name + " "+ msg; 
	}
	
	//define constructor argument value in beans.xml file when default constructor is not present.
	
//	public HelloWorldBean(String msg) {
//		System.out.println("Constructor");
//		this.msg = msg;
//	}

}
