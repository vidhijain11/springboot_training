package com.geek.bean;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {
  public static void main (String[] args) {
	  ApplicationContext ctx = new ClassPathXmlApplicationContext("beans.xml"); // initalizing spring/ioc container using Application context.
	  HelloWorldBean bean = (HelloWorldBean) ctx.getBean("hellobean"); //getting the bean defined in xml file
	  System.out.println(bean.sayHello("Vidhi hiieee"));
	  
	  //all beans are singleton -- by default spring container makes only one object for each class 
	  // scope types - 
	  // --- 1) singleton (default), 
	  //----- 2) prototype (new object for every time)
	  //------3) request, session, application (supports java in EE)
	  HelloWorldBean bean2 = (HelloWorldBean) ctx.getBean("hellobean");
	  System.out.print(bean==bean2); //result = true
	  
	  
	  //wheather you are using or not using any bean. By default spring creates all the beans that results in slow startup. 
	  //use lazy init to create object only when it is required.
	  //by default lazy-init is false.
	  
	  
	  
  }
}
